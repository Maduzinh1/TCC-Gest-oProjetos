package com.example.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("aula", "onCreate");
        int num1;
        TextView tvReslt = (TextView) findViewById(R.id.tvReslt);
        EditText edtNum1 = (EditText) findViewById(R.id.edtNum1);
        EditText edtNum2 = (EditText) findViewById(R.id.edtNum2);
        Button btSoma = (Button) findViewById(R.id.btSoma);
        Button btSub = (Button) findViewById(R.id.btSub);
        Button btMult = (Button) findViewById(R.id.btMult);
        Button btDiv = (Button) findViewById(R.id.btDiv);

        btSoma.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int num = Integer.parseInt(edtNum1.getText().toString());
                tvReslt.setText(Integer.toString(num));
            }
        }
        btSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view){
                int num = Integer.parseInt(edtNum2.getText().toString());
                tvReslt.setText(Integer.toString(num));
                }
            }

            {
            })
        })
        });

// num1 + num2. button Calcular. Resultado

    }

    public MainActivity() {
        super();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d("aula", "onStart");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("aula", "onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("aula", "onDestroy");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("aula", "onPause");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("aula", "onResume");
    }
}